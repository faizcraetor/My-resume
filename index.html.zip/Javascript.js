const sectionsData = [
  "👋 My Name: Faiz Muhammad Bhanbhro",
  "👨 Father's Name: Sher Muhammad Bhanbhro",
  "🎓 Education:<br>✓ Intermediate – 81%<br>✓ Diploma in IT<br>✓ BS Software Engineering at Sindh Agriculture University, Umerkot",
  "💡 Skills:<br>✓ Web Development<br>✓ Teaching<br>✓ Computing",
  "📚 Experience: 5 Years in Home Tuition Center",
  "🙏❤️ Thanks for visiting my first website<br>⭐ Please give 5 stars"
];

// Random colors and animations
const colors = ["#f44336", "#9c27b0", "#3f51b5", "#03a9f4", "#4caf50", "#ff9800", "#795548"];
const animations = ["fadeIn", "zoomIn", "slideIn", "rotateIn", "flipIn"];

const container = document.getElementById("main");

sectionsData.forEach((text, index) => {
  setTimeout(() => {
    const section = document.createElement("div");
    section.className = "section";
    
    // Set random background color
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    section.style.backgroundColor = randomColor;
    
    // Set random animation
    const randomAnimation = animations[Math.floor(Math.random() * animations.length)];
    section.style.animation = `${randomAnimation} 1s ease`;
    
    // Add content with label
    section.innerHTML = `<span class="faiz-label">FaizCreator</span>${text}`;
    
    container.appendChild(section);
    
    // Show with transition
    setTimeout(() => {
      section.classList.add("show");
    }, 100);
  }, index * 1800); // delay each section
});
